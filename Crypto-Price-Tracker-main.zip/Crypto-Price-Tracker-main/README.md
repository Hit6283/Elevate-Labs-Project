# Crypto-Price-Tracker
Crypto Price Tracker is a Python-based web app that helps you monitor live cryptocurrency prices, set alerts, and receive email notifications when price thresholds are met. The CoinGecko API for real-time data and provides an interactive dashboard built with Streamlit.Live Price Tracking – Fetch real-time cryptocurrency prices from CoinGecko.   
