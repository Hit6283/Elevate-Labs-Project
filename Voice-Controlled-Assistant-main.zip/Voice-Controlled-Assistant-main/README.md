# Voice-Controlled-Assistant
The Voice-Controlled Assistant is a Python-based project that enables users to interact with their computer using natural voice commands. Built with speech_recognition and pyttsx3, it listens to user input, processes speech into text, executes mapped actions, and responds through speech output.
