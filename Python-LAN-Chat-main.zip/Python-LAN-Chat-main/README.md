# Python-LAN-Chat
This project is a simple local real-time chat application built using Python sockets, threading, and Tkinter. It allows multiple users on the same Local Area Network (LAN) to connect, exchange messages, and maintain a smooth chat experience with a graphical interface.🔧 Tools &amp; Technologies  Python , LAN Communication  File Handling (for logs)
